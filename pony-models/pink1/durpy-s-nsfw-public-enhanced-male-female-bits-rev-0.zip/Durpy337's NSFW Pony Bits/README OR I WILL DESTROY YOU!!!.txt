You've been chosen or have been chosen to download my horsie nsfw bits. You pervert!!! B-BAKA!!

..::Description::..
This is the horsecock model and pony pussy model I've used in my previous works and now you have the opportunity to fuck around with it yourself! This model hasn't been touched (From the SFM) side for a really long time, however I did make some minor changes and added a few more flexes and a bone for moving the ponut. There MAY be some unusual things that could occur with the model. I don't think I'll be updating it much at all really because I don't see much of a reason to do so. The model is also just intended to be used only in SFM and maybe Gmod..maybe (I never tested it).


Since you currently have this model, here are some ground rules because if you break them. I have a very particular set of skills, and I will find you. And I will cock slap you.


..::Rules::..
-Do not claim ownership of this model.
-You may modify the model at your own discretion, such as adding flexes changing some verts here.
-Upon modifying the model, this doesn't give you ownership of it. I'm still the OG creator.
-You may post your modifications of the model online, as long as credit is given.
-When posting an image whilst using this model you don't have an obligation to credit me unless asked.
-If someone asks for the model, you're free to provide the download link.


..::Installation::..
Install to your SFM folder typically located [X:\Program Files\steam\steamapps\common\SourceFilmmaker\game\<WHATEVERFOLDER>]



Thanks for your time, and keep up the good work.



..::Credits::..
Models Created By: Durpy337


..::Social Media::..
Discord: Durpy#6532
Steam: https://steamcommunity.com/id/xDeRpYx/
Twitter: https://twitter.com/Durpy337
Derpibooru: https://derpibooru.org/profiles/Durpy337
Tumblr: ...Lol?


..::Addendum::..
Please don't add me because you think I'm a cool nibba and then never speak to me or interact with me. Lowkey I will remove you, if you don't talk to me, discuss stuff about my model, or even do anything else. Also I'm not a teacher.

Love y'all. Make me proud..I can't wait to see what you guys come up with.